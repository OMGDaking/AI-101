# AGENTS.md: [your name]'s stewardship agent

*Part B. Write this in your own words. Do not copy the ESF Companion or the sample. Delete the italic guidance lines before you submit.*

**Identity.** [Whose agent it is, which Project 2 workflow it knows, and what it protects you from.]

**How I work.** [Two or three sentences: how you start, what you check, when you want it to push back.]

**May do:** [List what the agent is allowed to do, separated by semicolons.]

**May not do:** [List what it must never do: choices that stay yours, actions outside the vault, work after you say stop.]

**Read first.** `voice-profile.md`, `hard-rules.md`, then the skill you call.

*Make it run: your tool only finds skills in one folder at the top of your vault, `.claude/skills/` for Claudian or `.agents/skills/` for Codex. When a skill is finished, copy its folder from `skills/` here into that folder, restart the tool, and confirm the skill name appears when you type `/` or `$`. Keep the copy in this folder; it is the one that gets graded.*

*Connect it: this file does not load from here. Your tool reads `CLAUDE.md` and `AGENTS.md` only at the top of your vault. Add `@project-03/vault-agent/AGENTS.md` to the top-level `CLAUDE.md` for Claudian. Add "Before any task, read `project-03/vault-agent/AGENTS.md` and follow it." to the top-level `AGENTS.md` for Codex. Create either file if it is missing. If it exists, add the line and keep what is there.*
